<?php //authenticate2.php
	require_once 'login.php';
	$db_server = new mysqli($db_hostname, $db_username, $db_password, $db_database);
	if ($db_server->connect_error) die("Unable to connect to MySQL: " . $db_server->connect_error);

	if (isset($_SERVER['PHP_AUTH_USER']) &&
	isset($_SERVER['PHP_AUTH_PW']))
	{
		$un_temp = mysqli_entities_fix_string($db_server, $_SERVER['PHP_AUTH_USER']);
		$pw_temp = mysqli_entities_fix_string($db_server, $_SERVER['PHP_AUTH_PW']);
		$query = "SELECT * FROM users WHERE email='$un_temp'";
		$result = $db_server->query($query);
		if (!$result) die("Database access failed: " . $db_server->error);
		elseif ($result->num_rows)
		{
			$row = $result->fetch_row();
			$salt1 = "qm&h*";
			$salt2 = "pg!@";
			$token = md5("$salt1$pw_temp$salt2");
			if ($token == $row[3])
			{
				session_start();
				$_SESSION['email'] = $un_temp;
				$_SESSION['password'] = $pw_temp;
				$_SESSION['firstname'] = $row[0];
				$_SESSION['surname'] = $row[1];
				echo "$row[0] $row[1] : Hi $row[0],
				you are now logged in as '$row[2]'";
				die ("<p><a href=continue.php>Click here to continue</a></p>");
			}
			else die("Invalid username/password combination");
		}
		else die("Invalid username/password combination");
	}

	else
	{
		header('WWW-Authenticate: Basic realm="Restricted Section"');
		header('HTTP/1.0 401 Unauthorized');
		die ("Please enter your username and password");
	}

	function mysqli_entities_fix_string($db_server, $string)
	{
		return htmlentities(mysqli_fix_string($db_server, $string));
	}

	function mysqli_fix_string($db_server, $string)
	{
		return $db_server->real_escape_string($string);
	}
	
?>
