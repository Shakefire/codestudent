<?php
	$mysqli = new mysqli("localhost", "root", "", "dataset");
	if ($mysqli->connect_error) {
		die("Couldn't connect! Error: " . $mysqli->connect_error);
	}
	// Set charset to utf8 if needed
	$mysqli->set_charset("utf8");
	
	// Make connection available globally if needed
	$GLOBALS['mysqli'] = $mysqli;
?>
