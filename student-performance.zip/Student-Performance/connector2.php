<?php
	$mysqli = new mysqli("localhost", "root", "", "register");
	if ($mysqli->connect_error) {
		die("Couldn't connect! Error: " . $mysqli->connect_error);
	}
	// Set charset to utf8 if needed
	$mysqli->set_charset("utf8");
	
	// Make connection available globally if needed
	$GLOBALS['mysqli_register'] = $mysqli;
?>
