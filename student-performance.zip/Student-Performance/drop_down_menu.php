</<!DOCTYPE html>
<html>
<head>
	<title> Untitled Document</title>
</head>
<body>
	<select name="Esther" id="Esther">
		<option value="0" selected="selected"> <a href="student_homepage.html"> Esther <a/>  </option>
		<option value="settings"> Settings </option>
		<option value="logout"> Logout </option>
	</select>

</body>
</html>