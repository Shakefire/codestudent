<?php

	$conn = mysqli_connect("localhost", "root", "", "dataset") or die("Couldn't connect!");

	$query1 = mysqli_query($conn, "SELECT * FROM student_data");
	$count1 = mysqli_num_rows($query1);
	//echo "$count1";

	error_reporting(E_ALL ^ E_NOTICE);
	$query2 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'Low' && certified = '1'");
	$count2 = mysqli_num_rows($query2);
	//echo "$count2";

	$query3 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'Low' && certified = '0'");
	$count3 = mysqli_num_rows($query3);
	//echo "$count3";

	$query4 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'High' && certified = '0'");
	$count4 = mysqli_num_rows($query4);
	//echo "$count4";

	$query5 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'High' && certified = '1'");
	$count5 = mysqli_num_rows($query5);
	//echo "$count5";

	$query6 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'Low'");
	$count6 = mysqli_num_rows($query6);
	//echo "$count6";

	$query7 = mysqli_query($conn, "SELECT * FROM student_data where risk_level = 'High'");
	$count7 = mysqli_num_rows($query7);
	//echo "$count7";

	$true_positive_rate = (($query2/$query6));
	//echo "$true_positive_rate";

	$false_positive_rate = (($query3/$query6));
	//echo "$false_positive_rate";

	$true_negative_rate = (($query4/$query7));
	//echo "$true_negative_rate";

	$false_negative_rate = (($query5/$query7));
	//echo "$false_negative_rate";

	$correct = $count2+$count4;
	//echo "$correct";

	$classification_rate = ($count2+$count4)/($count6+$count7);
	echo "$classification_rate";




?>
